#include <iostream>
#include <exception>
using namespace std;

class MyException : public exception {
 public:
   const char * what () const throw ()
   {
     return "Division by zero. ";
   }
};

int safeDiv(int divident, int divisor)
{
  if (divisor == 0) 
    throw MyException();
  return divident / divisor;
}


int main()
{
  try
  {
    throw(1);
    // safeDiv(3, 0);
  }
  catch(MyException& exc)
  {
    std::cout << "MyException caught" << std::endl;
    std::cout << exc.what() << std::endl;
  }
  catch(std::exception& e)
  {
    //Other errors
  }
}
