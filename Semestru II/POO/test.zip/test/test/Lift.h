#pragma once

#include "Materie.h"

class Lift : public Materie
{
public:
	Lift(string nume, string tip) : Materie(nume, tip) {}
	virtual void Build()
	{
		cout << "LIFT: " << name << " : " << tip << endl;
		for (auto it : *this)
			it->Build();
	}
};