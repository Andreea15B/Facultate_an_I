#include <iostream>
#include <initializer_list>

using namespace std;

#define DIM_MAX 100

class MyIterator
{
    const char **p;
public:

    MyIterator(const char **tmp)
    {
        //cout << "Constructor: " << this << endl;
        p = tmp;
    }
    ~MyIterator()
    {
        //cout << "Destructor: " << this << endl;;
    }

    /*
        Pentru a fi sigur ca functioneaza in orice situatie, am supraincarcat ambii operatori (postfixat/prefixat)
    */

    MyIterator& operator ++()
    {
        p++;
        return *this;
    }

    MyIterator& operator ++(int)
    {
        p++;
        return *this;
    }

    bool operator !=(const MyIterator &tmp)
    {
        return p != tmp.p;
    }

    const char* operator *()
    {
        return *p;
    }
};

class StrVector
{
    const char *siruri[DIM_MAX];
    int Count;

public:
    StrVector(initializer_list<const char*> l)
    {
        Count = 0;

        for (auto it = l.begin(); it != l.end(); ++it)
            siruri[Count++] = *it;

        /*
            auto va fi inlocuit cu initializer_list<const char*>::iterator
            Deci dupa compilare for-ul ar arata in felul urmator:

            for (initializer_list<const char*>::iterator it = l.begin(); it != l.end(); ++it)
        */
    }

    int GetCount()
    {
        return Count;
    }

    /*
        Pentru functiile GetIterator, begin, end...
        Cel mai simplu e sa returnati direct obiecte (cum e si mai jos).
    */

    MyIterator GetIterator()
    {
        MyIterator tmp(&siruri[0]);
        return tmp;
    }

    MyIterator begin()
    {
        //cout << "Inceput Begin ------ " << endl << endl;
        
        MyIterator tmp(&siruri[0]);
        return tmp;

        //cout << "Sfarsit Begin ------ " << endl << endl;
    }

    MyIterator end()
    {
        //cout << "Inceput End ------ " << endl << endl;
        
        MyIterator tmp(&siruri[Count]);
        return tmp;

        //cout << "Sfarsit End ------ " << endl << endl;
    }
};

int main()
{
    StrVector v = { "Test" , "for" , "C++" };
    auto it = v.GetIterator();
    auto count = v.GetCount();
    for (auto index = 0;index<count;index++, it++)
        printf("%s\n", *it); 
    
    for (auto element : v)
        printf("%s\n", element);
}