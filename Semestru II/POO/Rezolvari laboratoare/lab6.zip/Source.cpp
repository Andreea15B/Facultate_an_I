#include <stdlib.h>
#include <vector>
#include <deque>
#include <queue>
#include <stack>

using namespace std;

#define MAX_SIZE 100

class cmp //folosita la priority_queue pentru a a sorta in ordine alfabetica
{
public:
	bool operator ()(const char *s1, const char *s2)
	{
		return stricmp(s1, s2) > 0;
	}
};

/*
	Functia Print este supraincarcata pentru a afisa toate tipurile de obiecte: vector, deque, priority_queue.
	Pentru vector/deque am trimis parametrul folosind referinta (&). Asta inseamna ca dupa ce iese din functie, se pastreaza modificarile.
	La priority_queue nu am folosit referinta din cauza ca pop imi scoate cate un element din coada. 
	Daca folosesc referinta, atunci cand iese din functie, coada va avea 0 elemente.
	Ca sa testati, inlocuiti in lista de parametri q cu &q si apelati de 2 ori functia Print(q)
*/
void Print(vector<const char*>&v)
{
	vector<const char*>::iterator it; //parcurgere cu iteratori
	for (it = v.begin(); it != v.end(); ++it)
	{
		printf("%s\n", *it);
	}
	printf("\n==============\n\n");
}

void Print(deque<const char*>&d)
{
	deque<const char*>::iterator it;
	for (it = d.begin(); it != d.end(); ++it)
	{
		printf("%s\n", *it);
	}
	printf("\n==============\n\n");
}

void Print(priority_queue<const char*, vector<const char*>, cmp>q)
{
	
	while (q.size())
	{
		printf("%s\n", q.top());
		q.pop();
	}
	printf("\n==============\n\n");
}


const char* cel_mai_lung_cuvant(vector<const char*>&v)
{
	vector<const char*>::iterator it;
	int lungime_maxima = 0;
	const char *res = NULL;

	for (it = v.begin(); it != v.end(); ++it)
	{
		if (strlen(*it) > lungime_maxima)
		{
			lungime_maxima = strlen(*it);
			res = *it;
		}
	}

	return res;
}

int numar_vocale(const char *sir)
{
	int res = 0;
	for (int i = 0; i < strlen(sir); i++) //se pot folosi si alte metode pentru a calcula numarul de vocale
	{
		switch (sir[i])
		{
		case 'a':
		case 'e':
		case 'i':
		case 'o':
		case 'u':
		case 'A':
		case 'E':
		case 'I':
		case 'O':
		case 'U':
			res++;
			break;
		default:
			break;
		}
	}

	return res;
}

int cuvinte4vocale(vector<const char*> &v)
{
	int res = 0;

	for (int i = 0; i < v.size(); i++) //parcurgere folosing indexi
	{
		if (numar_vocale(v[i]) >= 4)
			res++;
	}

	return res;
}

/*
Returns a pointer to the first occurrence of character in the C string str.
character = v[i][0]
str = vocale
*/
deque<const char*> construct_deque(vector<const char*>&v)
{
	deque<const char*>d;
	const char vocale[] = "aeiouAEIOU";

	for (int i = 0; i < v.size(); i++)
	{
		if (strchr(vocale, v[i][0]) == NULL)
		{
			d.push_back(v[i]);
		}
	}

	return d;
}



priority_queue<const char*, vector<const char*>, cmp> construct_priority_queue(vector<const char*>&v)
{
	priority_queue<const char*, vector<const char*>, cmp>q;

	for (int i = 0; i < v.size(); i++)
	{
		q.push(v[i]);
	}

	return q;
}

vector<const char*> construct_vector(vector<const char*>&v)
{
	stack<const char*>s;
	vector<const char*>v2;
	
	for (int i = 0; i < v.size(); i++)
	{
		s.push(v[i]);
	}

	while (s.size())
	{
		v2.push_back(s.top());
		s.pop();
	}

	return v2;
}

void delete_elements(vector<const char*>&v, int size)
{
	for (int i = 0; i < v.size(); i++)
	{
		if (strlen(v[i]) >= size)
		{
			v.erase(v.begin() + i);
			i--;
		}
	}
}


int main()
{
	FILE *fin = fopen("Text.txt", "r");
	char *s, *res;

	vector<const char*>v;

	do
	{
		s = new char[MAX_SIZE];
		res = fgets(s, MAX_SIZE, fin);
		if (res)
		{
			s[strcspn(s, "\r\n")] = 0;
			v.push_back(s);
		}
		else
			delete s;
		
	} while (res);

	deque<const char*>d = construct_deque(v);

	Print(v);
	printf("Cel mai lung cuvant: %s\n", cel_mai_lung_cuvant(v));
	printf("Numar cuvinte cu mai mult de 4 vocale: %d\n", cuvinte4vocale(v));
	printf("Deque:\n");
	Print(d);

	//delete_elements(v, 4);
	printf("After delete\n");
	Print(v);

	priority_queue<const char*, vector<const char*>, cmp>q = construct_priority_queue(v);
	printf("Queue\n");
	Print(q);
	
	vector<const char*>v2 = construct_vector(v);
	printf("Vector reverse\n");
	Print(v2);
}