#include <iostream>

class A
{
    public:
         ~A()
	 // ~A() noexcept(false) // C++ 2011
        {
            throw "Thrown by Destructor";
        }
};

int main()
{
    try
    {
        A   a;
    }
    catch(const char *exc)
    {
      std::cout << "Print " << exc << std::endl;
    }
    /*
    try
    {
        A   a;
        throw 2;
    }
    catch(...)
    {
        std::cout << "Never print this " << std::endl;
    }
    */
}
