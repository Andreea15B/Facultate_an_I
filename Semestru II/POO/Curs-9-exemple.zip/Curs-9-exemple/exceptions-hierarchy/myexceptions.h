#ifndef MYEXCEPTIONS_H
#define MYEXCEPTIONS_H 

// forward declaration
template <class T>
class Stack;



class Exception {
 public:
  virtual void debugPrint() {
    std::cout << "Exception: ";
  }
};


template <class T>
class StackException : public Exception {
 public:
  virtual void debugPrint() {
    this->Exception::debugPrint();
    std::cout << "Stack:";
  }
};

template <class T>
class StackOverflowException : public StackException<T>  {
 public:
  StackOverflowException(Stack<T>);
  virtual void debugPrint();
 private:
  Stack<T> stackErr;
};

template <class T>
class StackEmptyException : public StackException<T> {
 public:
  virtual void debugPrint();
};

class ArithmeticException : public Exception {
 public:
  void debugPrint() {
    this->Exception::debugPrint();
    std::cout << "Arithmetic:";
  }
};


class DivByZeroException : public ArithmeticException {
 public:
  DivByZeroException(int);
  void debugPrint();
 private:
  int divident;
};


template <class T>
StackOverflowException<T>::StackOverflowException(Stack<T> astack) 
{
  stackErr = astack;
}

template <class T>
void StackOverflowException<T>::debugPrint() 
{
  this->StackException<T>::debugPrint();
  std::cout << "Overflow." << std::endl;
  Stack<T> stCopy = stackErr;
  while ( ! stCopy.isEmpty() ) {
    std::cout << stCopy.top() << std::endl;
    stCopy.pop();
  }
}


template <class T>
void StackEmptyException<T>::debugPrint() 
{
  this->StackException<T>::debugPrint();
  std::cout << "Empty." << std::endl;
}

DivByZeroException::DivByZeroException(int x)
{
  divident = x;
}

void DivByZeroException::debugPrint()
{
  this->ArithmeticException::debugPrint();
  std::cout << "Division by zero. " << divident << std::endl;
}

#endif
