#include <iostream>
#include "myexceptions.h"

using namespace std;


#define MAX_STACK 5

template <class T>
class Stack
{
public:
  Stack();
  ~Stack();
  void push(T);
  void pop();
  T top();
  bool isEmpty(); 
private:
  T elt[MAX_STACK];
  int topIndex;
};

template <class T>
Stack<T>::Stack() {
  topIndex = 0;
}

template <class T>
Stack<T>::~Stack() {}

template <class T>
void Stack<T>::push(T x) 
{
  if (topIndex == MAX_STACK-1)
    throw StackOverflowException<T>(*this);
  elt[topIndex++] = x;
}

template <class T>
T Stack<T>::top()
{
  if ( isEmpty() ) 
    throw StackEmptyException<T>();
  return elt[topIndex-1];
}

template <class T>
bool Stack<T>::isEmpty()
{
  return topIndex < 0;
}

template <class T>
void Stack<T>::pop() 
{
  if ( isEmpty() )
    throw StackEmptyException<T>();
  --topIndex;
}
