// A simple program that computes the square root of a number
#include "firstprojwtestsConfig.h"
#include "firstprojwtests.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char* argv[])
{
  if (argc < 2) {
    fprintf(stdout, "%s Version %d.%d\n", argv[0], firstprojwtests_VERSION_MAJOR,
            firstprojwtests_VERSION_MINOR);
    fprintf(stdout, "Usage: %s number\n", argv[0]);
    return 1;
  }
  int inputValue = atoi(argv[1]);
  bool outputValue = IsPrime(inputValue);
  if (outputValue)
    fprintf(stdout, "The number %d is prime.\n", inputValue);
  else 
    fprintf(stdout, "The number %d is not prime.\n", inputValue);
  return 0;
}
