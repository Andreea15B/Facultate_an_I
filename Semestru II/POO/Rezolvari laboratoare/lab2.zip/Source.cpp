#include <stdio.h>
#include <stdlib.h>
#include "MyString.h"



int main()
{

	MyString s("poo");
	printf("%s\n", s.GetText());

	s.Set("Exemplu poo");
	printf("%s\n", s.GetText());

	s.Add(" 2018");
	printf("%s\n", s.GetText());

	MyString *s2 = s.SubString(8, 3);
	printf("%s\n", s2->GetText());

	s.Delete(8, 3);
	printf("%s\n", s.GetText());

	printf("%d\n", s.Compare(*s2));
	printf("%c\n", s.GetChar(3));


	s.Insert(9, "la ");
	printf("%s\n", s.GetText());

	printf("%d\n", s.Find("po"));
	printf("%d\n", s.Find("lu"));
	
	MyString s3("poo poo po poo op");
	printf("%d\n", s3.FindLast("poo"));
	
	return 0;
}