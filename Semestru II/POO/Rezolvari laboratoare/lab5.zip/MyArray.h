#pragma once
#include <stdlib.h>
#include <iostream>

using namespace std;

template<class T>
class MyArray
{
	T *data;
	int max_size;
	int size;

	bool increase_data_size()
	{

		max_size *= 2;

		T *tmp_data = (T*)realloc(data, max_size * sizeof(T));
		if (!tmp_data)
		{
			printf("Realloc fail\n");
			return false;
		}
		data = tmp_data;
	}

public:
	MyArray()
	{
		max_size = 8;
		size = 0;
		data = (T*)malloc(max_size * sizeof(T));
	}

	MyArray(int size)
	{
		this->size = size; 
		max_size = size;
		data = (T*)malloc(max_size * sizeof(T));
	}



	bool Add(T item)
	{
		if (size >= max_size)
		{
			bool res = increase_data_size();
			if (res == false)
				return false;
		}

		data[size++] = item;
		return true;
	}

	bool Add_at_pos(T item, unsigned pos)
	{
		if (pos >= size) // asta inseamna ca nu pot face append pe ultima pozitie. Daca vreau asta, trebuie sa folosesc Add
		{
			printf("Invalid position\n");
			return false;
		}

		if (size >= max_size)
		{
			bool res = increase_data_size();
			if (res == false)
				return false;
		}


		memcpy(data + pos + 1, data + pos, (size - pos) * sizeof(T));
		data[pos] = item;
		size++;
		return true;
	}

	void Erase(unsigned pos)
	{
		if (pos >= size)
		{
			printf("Invalid position\n");
			return;
		}

		memcpy(data + pos, data + pos + 1, (size - pos) * sizeof(T));
		size--;
	}

	void Print()
	{
		for (int i = 0; i < size; i++)
		{
			cout << data[i] << '\n';
		}
		cout << "\n===============================\n\n";
	}

	void Sort()
	{
		bool is_done;

		do
		{
			is_done = true;
			for(int i=0;i<size-1;i++)
				if (data[i] > data[i + 1])
				{
					T tmp = data[i];
					data[i] = data[i + 1];
					data[i + 1] = tmp;
					is_done = false;
				}

		} while (is_done == false);
	}

};







// ============= SPECIALIZATION===============

template<>
class MyArray<const char*>
{
	const char **data;
	int max_size;
	int size;

	bool increase_data_size()
	{

		max_size *= 2;

		const char **tmp_data = (const char **)realloc(data, max_size * sizeof(const char*));
		if (!tmp_data)
		{
			printf("Realloc fail\n");
			return false;
		}
		data = tmp_data;
	}

public:
	MyArray()
	{
		max_size = 8;
		size = 0;
		data = (const char**)malloc(max_size * sizeof(const char*));
	}

	MyArray(int size)
	{
		this->size = size;
		max_size = size;
		data = (const char**)malloc(max_size * sizeof(const char*));
	}



	bool Add(const char* item)
	{
		if (size >= max_size)
		{
			bool res = increase_data_size();
			if (res == false)
				return false;
		}

		data[size++] = item;
		return true;
	}

	bool Add_at_pos(const char* item, unsigned pos)
	{
		if (pos >= size) // asta inseamna ca nu pot face append pe ultima pozitie. Daca vreau asta, trebuie sa folosesc Add
		{
			printf("Invalid position\n");
			return false;
		}

		if (size >= max_size)
		{
			bool res = increase_data_size();
			if (res == false)
				return false;
		}


		memcpy(data + pos + 1, data + pos, (size - pos) * sizeof(const char*));
		data[pos] = item;
		size++;
		return true;
	}

	void Erase(unsigned pos)
	{
		if (pos >= size)
		{
			printf("Invalid position\n");
			return;
		}

		memcpy(data + pos, data + pos + 1, (size - pos) * sizeof(const char*));
		size--;
	}

	void Print()
	{
		for (int i = 0; i < size; i++)
		{
			cout << data[i] << '\n';
		}
		cout << "\n===============================\n\n";
	}

	void Sort()
	{
		bool is_done;

		do
		{
			is_done = true;
			for (int i = 0; i<size - 1; i++)
				if (strcmp(data[i], data[i+1]) > 0)
				{
					const char* tmp = data[i];
					data[i] = data[i + 1];
					data[i + 1] = tmp;
					is_done = false;
				}

		} while (is_done == false);
	}

};