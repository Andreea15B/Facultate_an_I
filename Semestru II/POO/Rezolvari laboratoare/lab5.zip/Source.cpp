#include "MyArray.h"



int main()
{
	MyArray<int> a;

	a.Add(7);
	a.Add(2);
	a.Add(1);
	a.Add(5);
	a.Add(3);
	a.Add(8);
	a.Add(4);
	a.Add(6);
	
	a.Print();

	a.Sort();
	a.Print();

	a.Add_at_pos(8, 3);
	a.Add_at_pos(10, 8);
	a.Print();

	a.Erase(5);
	a.Print();

	MyArray<const char*>s;

	s.Add("Poo");
	s.Add("1234");
	s.Add("c++");

	s.Print();

	s.Sort();
	s.Print();
}