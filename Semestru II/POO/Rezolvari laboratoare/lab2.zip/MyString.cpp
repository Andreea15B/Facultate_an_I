#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include "MyString.h"


MyString::MyString()
{
	AllocatedSize = 16 + 1; // +1 pentru NULL de la sfarsitul sirului
	Size = 0;
	sir = (char*)malloc(AllocatedSize * sizeof(char));
}

MyString::MyString(const char *text)
{
	AllocatedSize = strlen(text) + 1; // +1 pentru NULL de la sfarsitul sirului
	Size = AllocatedSize;
	sir = (char*)malloc(AllocatedSize * sizeof(char));
	strcpy(sir, text);
}

MyString::~MyString()
{
	free(sir);
}

unsigned int MyString::GetSize() 
{
	return Size;
}

void MyString::Set(const char *text)
{
	int newSize = strlen(text) + 1;
	
	if (newSize >= AllocatedSize)
	{
		char *tmp = (char*)realloc(sir, newSize * sizeof(char));
		if (tmp == NULL)
		{
			printf("Eroare la realloc\n");
			return;
		}
		sir = tmp;
		AllocatedSize = newSize;
	}

	strcpy(sir, text);
	Size = strlen(sir);
}

void MyString::Set(MyString &m)
{
	this->Set(m.GetText());
}

void MyString::Add(const char *text)
{
	int newSize = Size + strlen(text);

	if (newSize >= AllocatedSize)
	{
		char *tmp = (char*)realloc(sir, newSize * sizeof(char));
		if (tmp == NULL)
		{
			printf("Eroare la realloc\n");
			return;
		}
		sir = tmp;
		AllocatedSize = newSize;
	}

	strcat(sir, text);
	Size += strlen(text);
}

void MyString::Add(MyString &m)
{
	this->Add(m.GetText());
}

const char* MyString::GetText()
{
	return sir;
}

MyString* MyString::SubString(unsigned int start, unsigned int size)
{
	if (start >= Size || start + size >= Size)
	{
		printf("Substring invalid\n");
		return NULL;
	}

	char *s = (char*)malloc(size + 1 * sizeof(char));
	if (s == NULL)
	{
		printf("Eroare la malloc in SubString\n");
		return NULL;
	}

	memcpy(s, sir + start, size * sizeof(char));
	s[size] = NULL;

	MyString *tmp = new MyString(s);
	free(s);

	return tmp;
}

bool MyString::Delete(unsigned int start, unsigned int size)
{
	if (start >= Size || start + size >= Size)
	{
		return false;
	}

	strcpy(sir + start, sir + start + size);
	Size -= size;
	sir[Size] = 0;
}

int MyString::Compare(const char * text)
{
	return strcmp(sir, text);
}

int MyString::Compare(MyString &m)
{
	return strcmp(sir, m.GetText());
}

char MyString::GetChar(unsigned int index)
{
	return index >= Size ? 0 : sir[index];
}

bool MyString::Insert(unsigned int index, const char* text)
{
	if (index >= Size)
	{
		return false;
	}

	if (Size + strlen(text) >= AllocatedSize)
	{
		int newSize = Size + strlen(text) + 1;

		char *tmp = (char*)realloc(sir, newSize * sizeof(char));
		if (tmp == NULL)
		{
			printf("Eroare la realloc\n");
			return false;
		}
		sir = tmp;
		AllocatedSize = newSize;
	}

	int size_after_index = Size - index;
	
	char *tmp = (char*)malloc((size_after_index + 1) * sizeof(char));
	if (!tmp)
		return false;

	strcpy(tmp, sir + index);
	sir[index] = 0;
	strcat(sir, text);
	strcat(sir, tmp);
	Size += strlen(text);
	sir[Size] = 0;

	free(tmp);

	return true;

}

bool MyString::Insert(unsigned int index, MyString &m)
{
	return Insert(index, m.GetText());
}

int MyString::Find(const char * text)
{
	char* tmp = strstr(sir, text);

	return tmp ? tmp - sir : -1;

}

int MyString::FindLast(const char * text)
{
	for (int i = Size - strlen(text); i >= 0; i--)
	{
		if (strncmp(sir + i, text, strlen(text)) == 0)
		{
			return i;
		}
	}

	return -1;
}