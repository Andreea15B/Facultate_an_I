#include <iostream>
#include "stack.h"
using namespace std;

int main() {
  int i; char c = 'a';
  Stack<char> st; 
  try {
    for (i = 0; i <= 9; ++i) {
      st.push(c++);
      cout << st.top() << endl;
    }
  }
  catch(char const* msg) {
    cout << msg << endl;
  }
  return 0;
}
