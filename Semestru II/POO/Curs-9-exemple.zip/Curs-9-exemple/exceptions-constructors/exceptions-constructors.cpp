#include <iostream>
#include <exception>
#include <string>
#include <ctype.h>
#include <stdlib.h>

using namespace std;

// exceptii: constructori

class AA
{
public:
	AA(const char* s="\0") throw(int);
	~AA();
private:
	static int nrOb;
	int id;
	char* nume;
};

AA::AA(const char* s) throw(int)
{
	int n = strlen(s);
	nume = new char[n+1];
	strcpy(nume, s);
	nrOb++;
	id = nrOb;
	cout << id << " AA() "<< s << endl;;
	if (nrOb == 3) throw int(3);
	if (isdigit(s[0])) throw char(*s);
}

AA::~AA()
{
	cout << id << " ~AA()\n";
	delete [] nume;
	nrOb--;
}

void my_terminate()
{
	cout << "Revin in 5 min.\n";
	exit(1);
}

void my_unexpected()
{
	cout << "Exceptie neprevazuta.\n";
	//	throw;
        my_terminate();
}


int AA::nrOb = 0;
int main()
{
	set_unexpected(my_unexpected);
	set_terminate(my_terminate);
	try {
		AA a("start");
		AA* b = new AA[5];
		AA c("stop");
	} catch (int i) {
		cout << "Exceptie: " << i << endl;
	}
	try {
		AA d("1234");
	} catch (char c) {
		cout << "A fost aruncat " << c << endl;
	}
	return 0;
}

