#pragma once

extern "C" __declspec(dllexport) const char* GetName();

extern "C" __declspec(dllexport) int Compute(int, int);
